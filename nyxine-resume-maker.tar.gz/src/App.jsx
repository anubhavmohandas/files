import { useState, useEffect, useRef } from 'react';
import LandingPage from './components/LandingPage';
import WizardView from './components/WizardView';
import DashboardView from './components/DashboardView';
import GenerateView from './components/GenerateView';
import PreviewView from './components/PreviewView';
import { FileText, Briefcase, GraduationCap, Sparkles, Code, Award } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState('landing');
  const [currentStep, setCurrentStep] = useState(0);
  const [showStorageWarning, setShowStorageWarning] = useState(true);
  const [profile, setProfile] = useState({
    personal: { fullName: '', email: '', phone: '', location: '', linkedin: '', portfolio: '', github: '' },
    workExperience: [],
    education: [],
    skills: { technical: [], soft: [], certifications: [], languages: [] },
    projects: [],
    additional: { volunteer: '', awards: '', publications: '' }
  });
  const [savedResumes, setSavedResumes] = useState([]);
  const [currentResume, setCurrentResume] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const saveTimeoutRef = useRef(null);

  useEffect(() => {
    loadFromStorage();
  }, []);

  useEffect(() => {
    if (currentView !== 'landing') {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        saveToStorage();
      }, 2000);
    }
  }, [profile, savedResumes, currentView]);

  const loadFromStorage = () => {
    try {
      const profileData = localStorage.getItem('nyxine_profile');
      const resumesData = localStorage.getItem('nyxine_resumes');
      if (profileData) setProfile(JSON.parse(profileData));
      if (resumesData) setSavedResumes(JSON.parse(resumesData));
    } catch (error) {
      console.log('No saved data');
    }
  };

  const saveToStorage = () => {
    try {
      localStorage.setItem('nyxine_profile', JSON.stringify(profile));
      localStorage.setItem('nyxine_resumes', JSON.stringify(savedResumes));
    } catch (error) {
      console.error('Save error:', error);
    }
  };

  const steps = [
    { name: 'Personal', icon: FileText },
    { name: 'Work', icon: Briefcase },
    { name: 'Education', icon: GraduationCap },
    { name: 'Skills', icon: Sparkles },
    { name: 'Projects', icon: Code },
    { name: 'Additional', icon: Award }
  ];

  const exportData = () => {
    const dataStr = JSON.stringify({ profile, savedResumes }, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nyxine-backup-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importData = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target.result);
        if (data.profile) setProfile(data.profile);
        if (data.savedResumes) setSavedResumes(data.savedResumes);
        alert('Data imported successfully!');
      } catch (error) {
        alert('Import failed. Please check the file.');
      }
    };
    reader.readAsText(file);
  };

  const clearAllData = () => {
    if (confirm('Are you sure you want to delete all data? This cannot be undone.')) {
      try {
        localStorage.removeItem('nyxine_profile');
        localStorage.removeItem('nyxine_resumes');
        setProfile({
          personal: { fullName: '', email: '', phone: '', location: '', linkedin: '', portfolio: '', github: '' },
          workExperience: [],
          education: [],
          skills: { technical: [], soft: [], certifications: [], languages: [] },
          projects: [],
          additional: { volunteer: '', awards: '', publications: '' }
        });
        setSavedResumes([]);
        setCurrentView('landing');
        alert('All data cleared.');
      } catch (error) {
        console.error(error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {currentView === 'landing' && (
        <LandingPage 
          showStorageWarning={showStorageWarning}
          setShowStorageWarning={setShowStorageWarning}
          setCurrentView={setCurrentView}
          setCurrentStep={setCurrentStep}
          profile={profile}
        />
      )}
      
      {currentView === 'wizard' && (
        <WizardView
          currentStep={currentStep}
          setCurrentStep={setCurrentStep}
          steps={steps}
          profile={profile}
          setProfile={setProfile}
          setCurrentView={setCurrentView}
        />
      )}
      
      {currentView === 'dashboard' && (
        <DashboardView
          profile={profile}
          savedResumes={savedResumes}
          setCurrentView={setCurrentView}
          exportData={exportData}
          importData={importData}
          clearAllData={clearAllData}
          setSavedResumes={setSavedResumes}
          setCurrentResume={setCurrentResume}
        />
      )}
      
      {currentView === 'generate' && (
        <GenerateView
          setCurrentView={setCurrentView}
          profile={profile}
          savedResumes={savedResumes}
          setSavedResumes={setSavedResumes}
          isAnalyzing={isAnalyzing}
          setIsAnalyzing={setIsAnalyzing}
          setCurrentResume={setCurrentResume}
        />
      )}
      
      {currentView === 'preview' && currentResume && (
        <PreviewView
          resume={currentResume}
          setCurrentView={setCurrentView}
          profile={profile}
        />
      )}
    </div>
  );
}

export default App;
